import lab4_queue

def read_dictionary(filename):
    """Reads the file containing the list of words and stores it in wordlist"""
    wordlist = dict() # This will contain all of the words
    
    file = open(filename, 'r')
    for line in file:
        word = line.strip()
        length = len(word)
        if length in wordlist:
            wordlist[length].append(word)
        else:
            wordlist[length] = [word]
    
    return wordlist
    
def build_ladder(start, end):
    """Finds the shortest word ladder that connects start and end words.
    
    Returns None if such a ladder does not exist.
    """
    
    wordlist = read_dictionary('dictionary.txt') # Contains all of the allowed words
    
    used = set() # This will be a set of words that you have used while you searched
    
    word_ladders = lab4_queue.Queue() # This is your queue of stacks that will hold all of the word ladders in progress
    
    ###### Write more code here! ######
    
