import stacks

class Queue:
    def __init__(self):
        self.stackA = stacks.LinkedStack()
        self.stackB = stacks.LinkedStack()
        
    def is_empty(self):
        """Tests if the queue is logically empty"""
        pass # REPLACE
        
    def enqueue(self, item):
        """Puts item into the back of the queue"""
        pass # REPLACE
        
    def first(self):
        """Returns the element at the front of the queue, if it exists.
        
        Raises an IndexError if the queue is empty.
        """
        pass # REPLACE

    def dequeue(self):
        """Returns and removes the element at the front of the queue, if it exists.
        
        Raises an IndexError if the queue is empty.
        """
        pass # REPLACE
        
    def __len__(self):
        """Returns the size of the queue."""
        pass # REPLACE